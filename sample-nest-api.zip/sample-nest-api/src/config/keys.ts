export default {
	
	mongoURI: 'mongodb://localhost/nest'
};